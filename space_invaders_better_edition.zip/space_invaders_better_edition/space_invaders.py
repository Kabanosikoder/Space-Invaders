import pygame
import random
import time
import json
import os
import math
from PIL import Image

pygame.init()
pygame.mixer.init()

# Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
FPS = 60

CANNON_SPEED = 5
LASER_SPEED = 7

ALIEN_SPEED = 2
CANNON_FIRE_RATE = 0.5
SHOTGUN_FIRE_RATE = 0.75

POWERUP_SPAWN_FREQUENCY = 180

GIANT_LASER_DURATION = 4
DOUBLE_CANNON_DURATION = 12
SHOTGUN_DURATION = 8
SHOTGUN_SPREAD = 8

GIANT_LASER_WIDTH = 4
GIANT_LASER_GROWTH = 1

SHIELD_MAX_HP = 60
SHIELD_DECAY_RATE = 2

MEDKIT_DURATION = 5
MEDKIT_HEAL_RATE = 5

# Game constants
SCREEN_MARGIN = 40
EXPLOSION_FRAME_DURATION = 0.05
EXPLOSION_SIZE = (90, 80)
DIAGONAL_ANGLE = 20
CANNON_HEIGHT_OFFSET = 50

# Difficulty settings
EASY_DAMAGE = 5
MEDIUM_DAMAGE = 10
HARD_DAMAGE = 15

BOSS_HEALTH = 250
BOSS_SPEED = 2
BOSS_SIZE = (100, 100)
BOSS_LASER_DAMAGE = 12
BOSS_SHOTGUN_SPREAD = 15
HOMING_MISSILE_LIFETIME = 3.5

BOSS_ATTACK_COOLDOWN = 3
BOSS_LASER_COOLDOWN = 3
BOSS_SHOTGUN_COOLDOWN = 5
BOSS_GIANT_LASER_COOLDOWN = 12
BOSS_ROCKET_COOLDOWN = 7

PLAYER_LASER_DAMAGE = 10

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
CYAN = (0, 255, 255)

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Space Invaders")

try:
    background = pygame.image.load('space_background.gif').convert()
    background = pygame.transform.scale(background, (WINDOW_WIDTH, WINDOW_HEIGHT))
    
    # Load alien texture and create animation frames
    alien_frames = []
    try:
        alien_gif = Image.open('alien_texture.gif')
        for frame in range(alien_gif.n_frames):
            alien_gif.seek(frame)
            frame_image = alien_gif.convert('RGBA')
            frame_str = frame_image.tobytes()
            frame_size = frame_image.size
            pygame_surface = pygame.image.fromstring(frame_str, frame_size, 'RGBA').convert_alpha()
            pygame_surface = pygame.transform.scale(pygame_surface, (35, 35))
            alien_frames.append(pygame_surface)
    except Exception as e:
        print(f"Error loading alien animation: {e}")
        # Fallback to static image if GIF loading fails
        alien_image = pygame.Surface((35, 35))
        alien_image.fill((255, 0, 0))
        alien_frames = [alien_image]
    
    explosion_texture = pygame.image.load("explosion.gif").convert_alpha()
    pew_sound = pygame.mixer.Sound('laser.wav')
    collision_sound = pygame.mixer.Sound('collision.wav')
    game_over_sound = pygame.mixer.Sound('game_over.wav')
    
    pew_sound.set_volume(0.1)
    collision_sound.set_volume(0.45)

    alien_image = pygame.image.load('alien_texture.gif').convert_alpha()
    alien_image = pygame.transform.scale(alien_image, (40, 40))
    health_image = pygame.image.load('health.png').convert_alpha()
    health_image = pygame.transform.scale(health_image, (25, 25))
    player_space_ship = pygame.image.load('player_space_ship.png').convert_alpha()
    player_space_ship = pygame.transform.scale(player_space_ship, (80, 80))
    
    alien_frames = []
    for i in range(2):
        frame = alien_image.copy()
        if i == 1:
            frame = pygame.transform.scale(frame, (35, 35))
        alien_frames.append(frame)
        
    boss_texture = pygame.image.load('space_invader_boss1.png').convert_alpha()
    boss_texture = pygame.transform.scale(boss_texture, BOSS_SIZE)
    
    rocket_texture = pygame.image.load('rocket_homing.png').convert_alpha()
    rocket_texture = pygame.transform.scale(rocket_texture, (20, 30))
except (pygame.error, IOError, FileNotFoundError) as e:
    print(f"Couldn't load game assets: {e}")
    background = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
    background.fill(BLACK)
    
    alien_texture = pygame.Surface((30, 30))
    alien_texture.fill(GREEN)
    alien_frames = [alien_texture]
    
    explosion_texture = pygame.Surface((50, 50))
    explosion_texture.fill(RED)
    
    class DummySound:
        def play(self): pass
        def set_volume(self, v): pass
    
    pew_sound = DummySound()
    collision_sound = DummySound()
    game_over_sound = DummySound()

class Cannon(pygame.sprite.Sprite):
    def __init__(self, game):
        super().__init__()
        self.game = game
        self.base_image = player_space_ship
        self.image = self.base_image
        self.rect = self.image.get_rect()
        self.rect.centerx = WINDOW_WIDTH // 2
        self.rect.bottom = WINDOW_HEIGHT - CANNON_HEIGHT_OFFSET
        self.angle = 0
        
        # Create blue cannon shapes instead of using textures
        self.left_cannon = pygame.Surface((20, 30), pygame.SRCALPHA)
        pygame.draw.polygon(self.left_cannon, (0, 0, 255), [(10, 0), (20, 30), (0, 30)])
        
        self.right_cannon = pygame.Surface((20, 30), pygame.SRCALPHA)
        pygame.draw.polygon(self.right_cannon, (0, 0, 255), [(10, 0), (20, 30), (0, 30)])
        
        self.health = 100  # Initialize health
        self.max_health = 100  # Max health
        
        self.shield_hp = 0
        self.has_shield = False
        self.last_shield_decay = time.time()
        
        self.healing_active = False
        self.healing_end_time = 0
        self.last_heal_time = time.time()  # Add tracking for medkit healing
        
        self.last_shot = 0
        self.last_auto_shot = 0
        self.double_cannon_active = False
        self.double_cannon_end_time = 0
        self.shotgun_active = False
        self.shotgun_end_time = 0
        
    def update_rotation(self):
        if self.double_cannon_active:
            self.angle = 45  
        else:
            self.angle = 0  
            
        if self.angle != 0:
            self.image = pygame.transform.rotate(self.base_image, self.angle)
            self.rect = self.image.get_rect(center=self.rect.center)

    def move(self, direction):
        if direction == 'left' and self.rect.left > 0:
            self.rect.x -= CANNON_SPEED
        elif direction == 'right' and self.rect.right < WINDOW_WIDTH:
            self.rect.x += CANNON_SPEED

    def shoot(self, current_time):
        # Don't allow manual shooting if giant laser is active
        fire_rate = CANNON_FIRE_RATE
        if self.shotgun_active:
            fire_rate = SHOTGUN_FIRE_RATE  
            
        if current_time - self.last_shot < fire_rate:
            return None

        self.last_shot = current_time
        lasers = []

        if self.double_cannon_active and self.shotgun_active:
            angles = [-SHOTGUN_SPREAD*2, -SHOTGUN_SPREAD, 0, SHOTGUN_SPREAD, SHOTGUN_SPREAD*2]
            for angle in angles:
                left_laser = Laser(self.rect.centerx - 10, self.rect.top, angle)
                lasers.append(left_laser)
            
            for angle in angles:
                right_laser = Laser(self.rect.centerx + 10, self.rect.top, angle)
                lasers.append(right_laser)
            pew_sound.play()
            return lasers

        if self.shotgun_active:
            angles = [-SHOTGUN_SPREAD*2, -SHOTGUN_SPREAD, 0, SHOTGUN_SPREAD, SHOTGUN_SPREAD*2]
            for angle in angles:
                laser = Laser(self.rect.centerx, self.rect.top, angle)
                lasers.append(laser)
            pew_sound.play()
            return lasers

        if self.double_cannon_active:
            left_laser = Laser(self.rect.centerx - 10, self.rect.top, 0)
            right_laser = Laser(self.rect.centerx + 10, self.rect.top, 0)
            lasers.extend([left_laser, right_laser])
            pew_sound.play()
            return lasers

        laser = Laser(self.rect.centerx, self.rect.top, 0)
        lasers.append(laser)
        pew_sound.play()
        return lasers

    def update(self, current_time):
        if self.double_cannon_active and current_time >= self.double_cannon_end_time:
            self.double_cannon_active = False
            
        if self.shotgun_active and current_time >= self.shotgun_end_time:
            self.shotgun_active = False

        if self.has_shield:
            elapsed_time = current_time - self.last_shield_decay
            decay_amount = SHIELD_DECAY_RATE * elapsed_time
            self.shield_hp = max(0, self.shield_hp - decay_amount)
            self.last_shield_decay = current_time
            
            if self.shield_hp <= 0:
                self.has_shield = False

        return None

    def draw(self, screen):
        screen.blit(self.image, self.rect)
        if self.double_cannon_active:
            # Position the side cannons closer to the main cannon and raise them up
            left_pos = (self.rect.left + 5, self.rect.centery - 15)
            right_pos = (self.rect.right - 25, self.rect.centery - 15)
            screen.blit(self.left_cannon, left_pos)
            screen.blit(self.right_cannon, right_pos)

    def draw_shield(self, screen):
        if self.has_shield and self.shield_hp > 0:
            radius = 30
            rect = pygame.Rect(self.rect.centerx - radius, self.rect.top - radius//2, radius * 2, radius)
            pygame.draw.arc(screen, CYAN, rect, 0, math.pi, 3)

class Alien(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.frames = alien_frames
        self.current_frame = 0
        self.animation_speed = 0.1  # Faster animation
        self.last_frame_update = time.time()
        self.image = self.frames[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(-20, WINDOW_WIDTH - self.rect.width + 20)
        self.rect.y = random.randrange(-100, -40)
        self.speedy = ALIEN_SPEED
        self.speedx = random.choice([-1, 1]) * ALIEN_SPEED
        self.last_shot = 0
        
    def update(self):
        current_time = time.time()
        
        if current_time - self.last_frame_update > self.animation_speed:
            self.last_frame_update = current_time
            self.current_frame = (self.current_frame + 1) % len(self.frames)
            self.image = self.frames[self.current_frame]

        self.rect.x += self.speedx
        self.rect.y += self.speedy
        
        if self.rect.left < 0:
            self.speedx = abs(self.speedx)
        elif self.rect.right > WINDOW_WIDTH:
            self.speedx = -abs(self.speedx)
            
        if random.random() < 0.01:  
            self.speedx = random.choice([-1, 1]) * ALIEN_SPEED
            
        if self.rect.top > WINDOW_HEIGHT:
            self.rect.y = -30  
            self.rect.x = random.randrange(-20, WINDOW_WIDTH - self.rect.width + 20)
            
        if current_time - self.last_shot > 2:  
            if random.random() < 0.1:  
                self.last_shot = current_time
                laser = AlienLaser(self.rect.centerx, self.rect.bottom)
                all_sprites.add(laser)
                alien_lasers.add(laser)

class Laser(pygame.sprite.Sprite):
    def __init__(self, x, y, angle=0):
        super().__init__()
        self.width = 4
        self.height = 15
        
        surface_size = int(max(self.width, self.height) * 1.5)
        temp_surface = pygame.Surface((surface_size, surface_size), pygame.SRCALPHA)
        
        pygame.draw.rect(temp_surface, WHITE, 
                    (surface_size//2 - self.width//2, 
                     surface_size//2 - self.height//2, 
                     self.width, self.height))
        
        if angle != 0:
            self.image = pygame.transform.rotate(temp_surface, angle)
        else:
            self.image = pygame.Surface((self.width, self.height))
            self.image.fill(WHITE)
            
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.angle = angle
        self.x = float(x)  
        self.y = float(y)
        
    def update(self):
        angle_rad = math.radians(self.angle)
        self.x += LASER_SPEED * math.sin(angle_rad)
        self.y -= LASER_SPEED * math.cos(angle_rad)
        
        self.rect.centerx = round(self.x)
        self.rect.centery = round(self.y)
        
        if (self.rect.bottom < 0 or 
            self.rect.top > WINDOW_HEIGHT or 
            self.rect.right < 0 or 
            self.rect.left > WINDOW_WIDTH):
            self.kill()

class AlienLaser(pygame.sprite.Sprite):
    def __init__(self, x, y, angle=0):
        super().__init__()
        self.width = 4
        self.height = 10
        
        if angle != 0:
            # Create a larger surface for rotated laser
            surface_size = int(max(self.width, self.height) * 1.5)
            temp_surface = pygame.Surface((surface_size, surface_size), pygame.SRCALPHA)
            pygame.draw.rect(temp_surface, WHITE, 
                        (surface_size//2 - self.width//2, 
                         surface_size//2 - self.height//2, 
                         self.width, self.height))
            self.image = pygame.transform.rotate(temp_surface, angle)
        else:
            self.image = pygame.Surface((self.width, self.height))
            self.image.fill(WHITE)
            
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.top = y
        self.angle = angle
        
        # Calculate velocity based on angle
        if angle != 0:
            self.speedx = math.sin(math.radians(angle)) * 5
            self.speedy = math.cos(math.radians(angle)) * 5
        else:
            self.speedx = 0
            self.speedy = 5
        
    def update(self):
        if self.angle != 0:
            self.rect.x += self.speedx
            self.rect.y += self.speedy
        else:
            self.rect.y += self.speedy
            
        # Kill if it moves off the screen
        if self.rect.bottom < 0 or self.rect.top > WINDOW_HEIGHT:
            self.kill()

class Explosion(pygame.sprite.Sprite):
    def __init__(self, center_x, center_y):
        super().__init__()
        self.frames = []
        try:
            explosion_gif = Image.open('explosion.gif')
            self.frame_durations = []
            
            for frame in range(explosion_gif.n_frames):
                explosion_gif.seek(frame)
                self.frame_durations.append(EXPLOSION_FRAME_DURATION)
                
                frame_image = explosion_gif.convert('RGBA')
                frame_str = frame_image.tobytes()
                frame_size = frame_image.size
                pygame_surface = pygame.image.fromstring(frame_str, frame_size, 'RGBA').convert_alpha()
                pygame_surface = pygame.transform.scale(pygame_surface, EXPLOSION_SIZE)
                self.frames.append(pygame_surface)
                
        except Exception as e:
            print(f"Error loading explosion animation: {e}")
            fallback = pygame.Surface(EXPLOSION_SIZE)
            fallback.fill((255, 0, 0))
            self.frames = [fallback]
            self.frame_durations = [0.1]
        
        self.current_frame = 0
        self.image = self.frames[0]
        self.rect = self.image.get_rect()
        self.rect.center = (center_x, center_y)
        self.last_update = pygame.time.get_ticks()
        self.frame_duration = self.frame_durations[0]
        self.done = False
    
    def update(self):
        if self.done:
            self.kill()
            return
            
        now = pygame.time.get_ticks()
        elapsed = (now - self.last_update) / 1000.0
        
        if elapsed > self.frame_duration:
            self.last_update = now
            self.current_frame += 1
            
            if self.current_frame >= len(self.frames):
                self.done = True
                self.kill()
                return
            
            self.image = self.frames[self.current_frame]
            center = self.rect.center
            self.rect = self.image.get_rect(center=center)

class PowerUp(pygame.sprite.Sprite):
    def __init__(self, powerup_type):
        super().__init__()
        self.type = powerup_type
        if self.type == 'medkit':
            self.image = health_image
        else:
            self.image = pygame.Surface((20, 20))
            if self.type == 'double_cannon':
                self.image.fill((0, 0, 255))  
            elif self.type == 'shotgun':
                self.image.fill((255, 165, 0))  
            elif self.type == 'shield':
                self.image.fill(CYAN)  
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(SCREEN_MARGIN, WINDOW_WIDTH - SCREEN_MARGIN - self.rect.width)
        self.rect.y = -self.rect.height
        self.speedy = 3
        
    def update(self):
        self.rect.y += self.speedy
        if self.rect.top > WINDOW_HEIGHT:
            self.kill()


class HomingRocket(pygame.sprite.Sprite):
    def __init__(self, x, y, target, game):
        super().__init__()
        self.game = game
        self.original_image = rocket_texture
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.target = target
        self.speed = 3
        
        dx = self.target.rect.centerx - self.rect.centerx
        dy = self.target.rect.centery - self.rect.centery
        self.angle = math.degrees(math.atan2(dy, dx)) + 90
        
        self.image = pygame.transform.rotate(self.original_image, -self.angle)
        self.rect = self.image.get_rect(center=(x, y))
        self.spawn_time = time.time()
        
    def update(self):
        current_time = time.time()
        lifetime = current_time - self.spawn_time
        
        if lifetime >= HOMING_MISSILE_LIFETIME:
            explosion = Explosion(self.rect.centerx, self.rect.centery)
            self.game.explosions.add(explosion)
            self.game.all_sprites.add(explosion)
            self.kill()
            return
            
        dx = self.target.rect.centerx - self.rect.centerx
        dy = self.target.rect.centery - self.rect.centery
        distance = math.sqrt(dx * dx + dy * dy)
        
        if distance > 0:
            dx = dx / distance
            dy = dy / distance
            
            self.rect.x += dx * self.speed
            self.rect.y += dy * self.speed
            
            angle = math.degrees(math.atan2(dy, dx)) + 90
            self.image = pygame.transform.rotate(self.original_image, -angle)
            old_center = self.rect.center
            self.rect = self.image.get_rect()
            self.rect.center = old_center

class Mothership(pygame.sprite.Sprite):
    def __init__(self, game):
        super().__init__()
        self.game = game
        self.image = boss_texture
        self.rect = self.image.get_rect()
        self.rect.centerx = WINDOW_WIDTH // 2
        self.rect.y = 50
        self.health = BOSS_HEALTH
        self.speedx = BOSS_SPEED
        self.moving_right = True
        
        # Attack cooldowns
        self.last_laser_time = 0
        self.last_shotgun_time = 0
        self.last_giant_laser_time = 0
        self.last_rocket_time = 0
        self.currently_attacking = False
        self.attacks = ['laser', 'shotgun', 'giant_laser', 'rocket']
        self.last_attack = None  # Track the last used attack
        
        # Burst fire tracking
        self.burst_count = 0
        self.burst_start_time = 0
        self.burst_delay = 0.2  # 0.2 seconds between shots
        
        # For center laser attack
        self.charging_giant_laser = False
        self.firing_giant_laser = False
        self.charge_start_time = 0
        self.firing_start_time = 0
        self.original_pos = self.rect.centerx
        
    def take_damage(self, amount):
        self.health -= amount
        if self.health <= 0:
            # Store position before death
            death_pos = (self.rect.centerx, self.rect.centery)
            # Create death explosion first
            explosion = Explosion(death_pos[0], death_pos[1])
            self.game.explosions.add(explosion)
            self.game.all_sprites.add(explosion)
            # Then handle death effects
            self.game.bosses_killed.add(self)  # Add to set of killed bosses
            self.game.bonus_rounds_left = 3  # Next 3 rounds get bonuses
            self.kill()  # Remove from sprite groups
            self.game.boss = None  # Clear boss reference last
        return False
        
    def update(self):
        current_time = time.time()
        
        if not self.charging_giant_laser:
            if self.moving_right:
                self.rect.x += self.speedx
                if self.rect.right > WINDOW_WIDTH - 20:
                    self.moving_right = False
            else:
                self.rect.x -= self.speedx
                if self.rect.left < 20:
                    self.moving_right = True

        if self.charging_giant_laser:
            self.update_giant_laser()
            return

        if self.burst_count > 0:
            self.shoot_lasers()
            return

        if not self.currently_attacking and current_time - self.last_laser_time >= BOSS_ATTACK_COOLDOWN:
            can_laser = current_time - self.last_laser_time >= BOSS_LASER_COOLDOWN
            can_shotgun = current_time - self.last_shotgun_time >= BOSS_SHOTGUN_COOLDOWN
            can_giant = current_time - self.last_giant_laser_time >= BOSS_GIANT_LASER_COOLDOWN
            can_rocket = current_time - self.last_rocket_time >= BOSS_ROCKET_COOLDOWN
            
            available_attacks = []
            if can_laser and 'laser' != self.last_attack:
                available_attacks.append('laser')
            if can_shotgun and 'shotgun' != self.last_attack:
                available_attacks.append('shotgun')
            if can_giant and 'giant_laser' != self.last_attack:
                available_attacks.append('giant_laser')
            if can_rocket and 'rocket' != self.last_attack:
                available_attacks.append('rocket')
            
            if available_attacks:
                attack = random.choice(available_attacks)
                self.last_attack = attack
                self.currently_attacking = True
                
                if attack == 'laser':
                    self.shoot_lasers()
                elif attack == 'shotgun':
                    self.shoot_shotgun()
                elif attack == 'giant_laser':
                    self.start_giant_laser()
                elif attack == 'rocket':
                    self.fire_rocket()

    def shoot_lasers(self):
        current_time = time.time()
        
        # Start a new burst
        if self.burst_count == 0:
            self.burst_start_time = current_time
            self.burst_count = 1
            # Fire first laser
            laser = AlienLaser(self.rect.centerx, self.rect.bottom, 0)
            self.game.alien_lasers.add(laser)
            self.game.all_sprites.add(laser)
        # Continue burst
        elif current_time - self.burst_start_time >= self.burst_delay:
            self.burst_count += 1
            # Fire next laser
            laser = AlienLaser(self.rect.centerx, self.rect.bottom, 0)
            self.game.alien_lasers.add(laser)
            self.game.all_sprites.add(laser)
            self.burst_start_time = current_time
            
            # End burst after 3 shots
            if self.burst_count >= 3:
                self.burst_count = 0
                self.currently_attacking = False
                self.last_laser_time = current_time  # Reset cooldown when burst is complete

    def shoot_shotgun(self):
        # Create a spread of lasers
        for angle in range(-BOSS_SHOTGUN_SPREAD, BOSS_SHOTGUN_SPREAD + 1, 15):
            laser = AlienLaser(self.rect.centerx, self.rect.bottom, angle)
            self.game.alien_lasers.add(laser)
            self.game.all_sprites.add(laser)
        self.currently_attacking = False
        self.last_shotgun_time = time.time()

    def fire_rocket(self):
        # Launch rockets from the sides of the boss
        left_rocket = HomingRocket(self.rect.left - 20, self.rect.centery, self.game.cannon, self.game)
        right_rocket = HomingRocket(self.rect.right + 20, self.rect.centery, self.game.cannon, self.game)
        
        self.game.alien_lasers.add(left_rocket, right_rocket)
        self.game.all_sprites.add(left_rocket, right_rocket)
        self.currently_attacking = False
        self.last_rocket_time = time.time()

    def start_giant_laser(self):
        self.charging_giant_laser = True
        self.firing_giant_laser = False
        self.charge_start_time = time.time()
        self.original_pos = self.rect.centerx
        self.last_giant_laser_time = time.time()

    def update_giant_laser(self):
        current_time = time.time()
        
        # Charging phase (1 second)
        if not self.firing_giant_laser and current_time - self.charge_start_time >= 1:
            self.firing_giant_laser = True
            self.firing_start_time = current_time
        
        # Fire giant laser continuously for 2 seconds
        if self.firing_giant_laser:
            if current_time - self.firing_start_time <= 2:  # Fire for 2 seconds
                giant_laser = AlienLaser(self.rect.centerx, self.rect.bottom, 0)
                giant_laser.speedy = 10  # Make it move faster
                self.game.alien_lasers.add(giant_laser)
                self.game.all_sprites.add(giant_laser)
            else:
                # End giant laser attack
                self.charging_giant_laser = False
                self.firing_giant_laser = False
                self.currently_attacking = False

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        self.clock = pygame.time.Clock()
        self.running = True
        self.game_over = False
        self.wave_number = 0
        self.wave_active = False
        self.between_waves = False
        self.wave_break_duration = 5
        self.wave_break_start = 0
        self.wave_countdown = 0
        self.last_powerup_spawn = 0
        self.alien_damage = 10
        self.boss = None
        self.is_boss_wave = False
        self.last_heal_time = time.time()  # Add time tracking for healing
        
        # Boss kill tracking
        self.bosses_killed = set()  # Track which bosses have been killed
        self.bonus_rounds_left = 0
        self.show_health_bar = True
        
        self.all_sprites = pygame.sprite.Group()
        self.aliens = pygame.sprite.Group()
        self.lasers = pygame.sprite.Group()
        self.alien_lasers = pygame.sprite.Group()
        self.powerups = pygame.sprite.Group()
        self.explosions = pygame.sprite.Group()
        
        global all_sprites, alien_lasers
        all_sprites = self.all_sprites
        alien_lasers = self.alien_lasers
        
        self.cannon = Cannon(self)
        self.all_sprites.add(self.cannon)
        
        self.score = 0
        self.health = 75
        self.max_health = 75
        self.aliens_to_spawn = 0
        self.last_alien_spawn = 0
        self.powerup_spawn_timer = 0
        self.difficulty = None
        self.last_update = time.time()

    def show_difficulty_menu(self):
        menu_font = pygame.font.Font(None, 74)
        title_font = pygame.font.Font(None, 84)
        
        title_text = title_font.render('Select Difficulty', True, WHITE)
        easy_text = menu_font.render('Easy', True, WHITE)
        medium_text = menu_font.render('Medium', True, WHITE)
        hard_text = menu_font.render('Hard', True, WHITE)
        
        title_rect = title_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//4))
        easy_rect = easy_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2 - 50))
        medium_rect = medium_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2 + 50))
        hard_rect = hard_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2 + 150))
        
        selecting = True
        while selecting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if easy_rect.collidepoint(mouse_pos):
                        self.difficulty = 'easy'
                        self.alien_damage = EASY_DAMAGE
                        selecting = False
                    elif medium_rect.collidepoint(mouse_pos):
                        self.difficulty = 'medium'
                        self.alien_damage = MEDIUM_DAMAGE
                        selecting = False
                    elif hard_rect.collidepoint(mouse_pos):
                        self.difficulty = 'hard'
                        self.alien_damage = HARD_DAMAGE
                        selecting = False
            
            self.screen.fill(BLACK)
            self.screen.blit(title_text, title_rect)
            self.screen.blit(easy_text, easy_rect)
            self.screen.blit(medium_text, medium_rect)
            self.screen.blit(hard_text, hard_rect)
            pygame.display.flip()
        
        return True

    def show_restart_menu(self, final_score):
        self.screen.fill(BLACK)
        font = pygame.font.Font(None, 74)
        title = font.render('Game Over!', True, WHITE)
        title_rect = title.get_rect(center=(WINDOW_WIDTH//2, 100))
        self.screen.blit(title, title_rect)

        score_font = pygame.font.Font(None, 48)
        score_text = score_font.render(f'Final Score: {final_score}', True, WHITE)
        score_rect = score_text.get_rect(center=(WINDOW_WIDTH//2, 200))
        self.screen.blit(score_text, score_rect)

        buttons = ['Restart', 'Quit']
        button_height = 60
        button_width = 200
        spacing = 30
        start_y = 300

        selected = None
        while selected is None:
            mouse_pos = pygame.mouse.get_pos()
            
            for i, text in enumerate(buttons):
                button_y = start_y + i * (button_height + spacing)
                button_rect = pygame.Rect((WINDOW_WIDTH - button_width)//2, button_y, button_width, button_height)
                
                if button_rect.collidepoint(mouse_pos):
                    color = (100, 100, 100)  
                else:
                    color = (50, 50, 50)  
                
                pygame.draw.rect(self.screen, color, button_rect)
                
                font = pygame.font.Font(None, 36)
                text_surface = font.render(text, True, WHITE)
                text_rect = text_surface.get_rect(center=button_rect.center)
                self.screen.blit(text_surface, text_rect)
                
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if button_rect.collidepoint(mouse_pos):
                            return text == 'Restart'
            
            pygame.display.flip()

    def give_powerup(self, powerup_type, current_time):
        boss1_killed = 1 in self.bosses_killed
        duration_multiplier = 2 if boss1_killed and self.bonus_rounds_left > 0 else 1
        shield_multiplier = 2 if boss1_killed and self.bonus_rounds_left > 0 else 1
        
        if powerup_type == 'double_cannon':
            self.cannon.double_cannon_active = True
            self.cannon.double_cannon_end_time = current_time + (DOUBLE_CANNON_DURATION * duration_multiplier)
        elif powerup_type == 'shotgun':
            self.cannon.shotgun_active = True
            self.cannon.shotgun_end_time = current_time + (SHOTGUN_DURATION * duration_multiplier)
        elif powerup_type == 'shield':
            self.cannon.has_shield = True
            self.cannon.shield_hp = SHIELD_MAX_HP * shield_multiplier
            self.cannon.last_shield_decay = current_time
        elif powerup_type == 'medkit':
            heal_amount = 30 if not boss1_killed else 50
            self.cannon.health = min(self.cannon.max_health, self.cannon.health + heal_amount)

    def start_new_wave(self):
        self.wave_number += 1
        
        if self.bonus_rounds_left > 0:
            self.bonus_rounds_left -= 1
            
        if self.wave_number == 3:
            self.is_boss_wave = True
            self.boss = Mothership(self)
            self.all_sprites.add(self.boss)
            self.aliens_to_spawn = 4  # Fixed number of aliens during boss fight
        else:
            self.is_boss_wave = False
            base_aliens = 5 + self.wave_number * 2
            self.aliens_to_spawn = min(45, int(base_aliens))
        
        self.wave_active = True
        self.between_waves = False
        
        powerup_type = random.choice(['double_cannon', 'shotgun', 'shield', 'medkit'])
        powerup = PowerUp(powerup_type)
        self.powerups.add(powerup)
        self.all_sprites.add(powerup)
        
        if not self.is_boss_wave:
            # Spawn initial aliens for non-boss waves
            for _ in range(5 + self.wave_number):
                self.spawn_alien()
            
    def spawn_random_powerup(self):
        # List of available powerups with their weights
        available_powerups = []
        
        # Always include medkit and shield
        available_powerups.extend([('medkit', 30), ('shield', 20)])
        
        # Add weapon powerups
        available_powerups.extend([
            ('double_cannon', 25),
            ('shotgun', 25)
        ])
            
        # Calculate total weight
        total_weight = sum(weight for _, weight in available_powerups)
        
        # Choose random powerup based on weights
        rand_val = random.randint(1, total_weight)
        current_weight = 0
        
        for powerup_type, weight in available_powerups:
            current_weight += weight
            if rand_val <= current_weight:
                powerup = PowerUp(powerup_type)
                self.powerups.add(powerup)
                self.all_sprites.add(powerup)
                break

    def update(self, current_time):
        if self.game_over:
            return

        if self.between_waves:
            current_time = time.time()
            if current_time - self.wave_break_start >= self.wave_break_duration:
                self.end_wave_break()
            
            # Calculate actual elapsed time for healing
            elapsed_time = current_time - self.last_heal_time
            
            # Heal player during wave break (3 HP per second)
            if self.cannon:
                heal_amount = 3 * elapsed_time  # Reduced from 5 to 3 HP per second
                self.cannon.health = min(self.cannon.max_health, self.cannon.health + heal_amount)
                # Also heal shield if player has one
                if self.cannon.has_shield:
                    shield_heal = 1 * elapsed_time  # Reduced from 2 to 1 shield HP per second
                    self.cannon.shield_hp = min(SHIELD_MAX_HP, self.cannon.shield_hp + shield_heal)
            
            self.last_heal_time = current_time
            return
        
        # Update all game objects
        for sprite in self.all_sprites:
            if isinstance(sprite, Cannon):
                lasers = sprite.update(current_time)
                if lasers:
                    for laser in lasers:
                        self.lasers.add(laser)
                        self.all_sprites.add(laser)
            else:
                sprite.update()

        # Check for collisions between lasers and aliens/boss
        for laser in self.lasers:
            hits = pygame.sprite.spritecollide(laser, self.aliens, True)
            if hits:
                laser.kill()
                collision_sound.play()
                self.score += 10
                for hit in hits:
                    explosion = Explosion(hit.rect.centerx, hit.rect.centery)
                    self.explosions.add(explosion)
                    self.all_sprites.add(explosion)

            # Check for boss hits only if boss exists
            if self.boss and pygame.sprite.collide_rect(laser, self.boss):
                laser.kill()
                collision_sound.play()
                damage = PLAYER_LASER_DAMAGE
                # Create hit explosion
                explosion = Explosion(self.boss.rect.centerx, self.boss.rect.centery)
                self.explosions.add(explosion)
                self.all_sprites.add(explosion)
                # Apply damage (death handled in take_damage)
                self.boss.take_damage(damage)
                # Add score if boss was killed
                if not self.boss:  # Check if boss was removed by take_damage
                    self.score += 100
                else:
                    explosion = Explosion(self.boss.rect.centerx, self.boss.rect.centery)
                    self.explosions.add(explosion)
                    self.all_sprites.add(explosion)

        hits = pygame.sprite.spritecollide(self.cannon, self.alien_lasers, True)
        for hit in hits:
            if self.cannon.has_shield:
                self.cannon.shield_hp = max(0, self.cannon.shield_hp - 10)
                if self.cannon.shield_hp <= 0:
                    self.cannon.has_shield = False
            else:
                self.cannon.health = max(0, self.cannon.health - 10)  # Prevent negative health
                if self.cannon.health <= 0:
                    explosion = Explosion(self.cannon.rect.centerx, self.cannon.rect.centery)
                    self.explosions.add(explosion)
                    self.all_sprites.add(explosion)
                    self.game_over = True
                    game_over_sound.play()
                else:
                    collision_sound.play()

        if self.cannon.healing_active:
            if current_time >= self.cannon.healing_end_time:
                self.cannon.healing_active = False
            else:
                elapsed_time = current_time - self.cannon.last_heal_time  # Use elapsed time since last heal
                heal_amount = MEDKIT_HEAL_RATE * elapsed_time
                self.cannon.health = min(self.cannon.max_health, self.cannon.health + heal_amount)
                self.cannon.last_heal_time = current_time  # Update last heal time
        
        self.last_update = current_time
        
        lasers = self.cannon.update(current_time)
        if lasers:
            for laser in lasers:
                self.lasers.add(laser)
                self.all_sprites.add(laser)
            
        self.check_wave_completion()
        self.spawn_alien()
        self.spawn_powerups(current_time)
            
        hits = pygame.sprite.spritecollide(self.cannon, self.powerups, True)
        for powerup in hits:
            self.give_powerup(powerup.type, current_time)
            
    def start_wave_break(self):
        self.between_waves = True
        self.wave_break_start = time.time()
        self.wave_break_duration = 5
        
        for sprite in self.all_sprites:
            if isinstance(sprite, (Laser, AlienLaser)):
                sprite.kill()
        if hasattr(self.cannon, 'double_cannon_active'):
            self.stored_double_cannon_time = max(0, self.cannon.double_cannon_end_time - time.time())
            self.cannon.double_cannon_active = False
        if hasattr(self.cannon, 'shotgun_active'):
            self.stored_shotgun_time = max(0, self.cannon.shotgun_end_time - time.time())
            self.cannon.shotgun_active = False
        if hasattr(self.cannon, 'healing_active') and self.cannon.healing_active:
            self.stored_healing_time = max(0, self.cannon.healing_end_time - time.time())
            
    def end_wave_break(self):
        self.between_waves = False
        current_time = time.time()
        if hasattr(self, 'stored_double_cannon_time') and self.stored_double_cannon_time > 0:
            self.cannon.double_cannon_active = True
            self.cannon.double_cannon_end_time = current_time + self.stored_double_cannon_time
        if hasattr(self, 'stored_shotgun_time') and self.stored_shotgun_time > 0:
            self.cannon.shotgun_active = True
            self.cannon.shotgun_end_time = current_time + self.stored_shotgun_time
        if hasattr(self, 'stored_healing_time') and self.stored_healing_time > 0:
            self.cannon.healing_active = True
            self.cannon.healing_end_time = current_time + self.stored_healing_time
        self.start_new_wave()

    def draw_wave_info(self):
        if self.between_waves:
            font = pygame.font.Font(None, 48)
            time_left = max(0, self.wave_break_duration - (time.time() - self.wave_break_start))
            
            if (self.wave_number + 1) % 10 == 0:
                text = font.render(f'BOSS WAVE {self.wave_number + 1} starts in: {int(time_left)}', True, RED)
            else:
                text = font.render(f'Wave {self.wave_number + 1} starts in: {int(time_left)}', True, WHITE)
            
            text_rect = text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2 - 40))
            self.screen.blit(text, text_rect)
            
            score_text = font.render(f'Score: {self.score}', True, WHITE)
            score_rect = score_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2 + 40))
            self.screen.blit(score_text, score_rect)
        elif self.boss:
            # Draw boss health bar
            health_width = 100  # Width of health bar
            health_height = 10  # Height of health bar
            health_x = self.boss.rect.centerx - health_width // 2  # Center above boss
            health_y = self.boss.rect.top - 20  # 20 pixels above boss
            
            # Background (red)
            pygame.draw.rect(self.screen, RED, (health_x, health_y, health_width, health_height))
            # Foreground (green)
            current_health_width = (self.boss.health / BOSS_HEALTH) * health_width
            pygame.draw.rect(self.screen, GREEN, (health_x, health_y, current_health_width, health_height))
        else:
            font = pygame.font.Font(None, 36)
            wave_text = font.render(f'Wave: {self.wave_number}', True, WHITE)
            wave_rect = wave_text.get_rect(topright=(WINDOW_WIDTH - 220, 10))
            self.screen.blit(wave_text, wave_rect)
            
            aliens_left = len(self.aliens) + self.aliens_to_spawn
            alien_text = font.render(f'Aliens: {aliens_left}', True, WHITE)
            alien_rect = alien_text.get_rect(topright=(WINDOW_WIDTH - 220, 45))
            self.screen.blit(alien_text, alien_rect)

    def check_wave_completion(self):
        if not self.between_waves:
            if self.is_boss_wave:
                if not self.boss:  # Only complete wave when boss is defeated
                    self.start_wave_break()
            elif self.aliens_to_spawn <= 0 and len(self.aliens) == 0:
                self.start_wave_break()

    def spawn_alien(self):
        if not self.between_waves and self.aliens_to_spawn > 0 and len(self.aliens) < 20 and time.time() - self.last_alien_spawn >= 1.2:
            alien = Alien()
            self.aliens.add(alien)
            self.all_sprites.add(alien)
            self.last_alien_spawn = time.time()
            self.aliens_to_spawn -= 1

    def spawn_powerups(self, current_time):
        if not self.between_waves:  
            self.powerup_spawn_timer += 1
            
            if self.powerup_spawn_timer >= 180:
                self.powerup_spawn_timer = 0
                if random.random() < 0.1:  
                    powerup_types = ['double_cannon', 'shotgun', 'shield', 'medkit']
                    powerup_type = random.choice(powerup_types)
                    powerup = PowerUp(powerup_type)
                    self.powerups.add(powerup)
                    self.all_sprites.add(powerup)

    def get_player_name(self):
        name = ""
        input_active = True
        font = pygame.font.Font(None, 36)
        
        while input_active:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and name:
                        input_active = False
                    elif event.key == pygame.K_BACKSPACE:
                        name = name[:-1]
                    elif event.key == pygame.K_ESCAPE:
                        return "Player"  
                    elif len(name) < 15:  
                        name += event.unicode
                        
            self.screen.fill(BLACK)
            text_surface = font.render(f"Enter your name: {name}", True, WHITE)
            text_rect = text_surface.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2))
            self.screen.blit(text_surface, text_rect)
            
            instruction = font.render("Press Enter to confirm or Escape to skip", True, (128, 128, 128))
            instruction_rect = instruction.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2 + 50))
            self.screen.blit(instruction, instruction_rect)
            
            pygame.display.flip()
            
        return name if name else "Player"

    def show_restart_menu(self, final_score):
        self.screen.fill(BLACK)
        font = pygame.font.Font(None, 74)
        title = font.render('Game Over!', True, WHITE)
        title_rect = title.get_rect(center=(WINDOW_WIDTH//2, 100))
        self.screen.blit(title, title_rect)

        score_font = pygame.font.Font(None, 48)
        score_text = score_font.render(f'Final Score: {final_score}', True, WHITE)
        score_rect = score_text.get_rect(center=(WINDOW_WIDTH//2, 200))
        self.screen.blit(score_text, score_rect)

        buttons = ['Restart', 'Quit']
        button_height = 60
        button_width = 200
        spacing = 30
        start_y = 300

        selected = None
        while selected is None:
            mouse_pos = pygame.mouse.get_pos()
            
            for i, text in enumerate(buttons):
                button_y = start_y + i * (button_height + spacing)
                button_rect = pygame.Rect((WINDOW_WIDTH - button_width)//2, button_y, button_width, button_height)
                
                if button_rect.collidepoint(mouse_pos):
                    color = (100, 100, 100)  
                else:
                    color = (50, 50, 50)  
                
                pygame.draw.rect(self.screen, color, button_rect)
                
                font = pygame.font.Font(None, 36)
                text_surface = font.render(text, True, WHITE)
                text_rect = text_surface.get_rect(center=button_rect.center)
                self.screen.blit(text_surface, text_rect)
                
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if button_rect.collidepoint(mouse_pos):
                            return text == 'Restart'
            
            pygame.display.flip()

    def save_score(self):
        scores = []
        if os.path.exists('scores.json'):
            try:
                with open('scores.json', 'r') as f:
                    scores = json.load(f)
            except:
                scores = []
        
        scores.append({"name": self.player_name, "score": self.score})
        scores.sort(key=lambda x: x["score"], reverse=True)
        scores = scores[:10]  
        
        try:
            with open('scores.json', 'w') as f:
                json.dump(scores, f)
        except:
            pass  

    def draw_health_bar(self):
        # Draw player health bar
        health_width = 200
        health_height = 20
        health_x = 20
        health_y = 20
        
        # Background (red)
        pygame.draw.rect(self.screen, RED, (health_x, health_y, health_width, health_height))
        
        # Only draw health if player exists and is alive
        if hasattr(self, 'cannon') and self.cannon and hasattr(self.cannon, 'health') and self.cannon.health > 0:
            current_health_width = (self.cannon.health / self.cannon.max_health) * health_width
            pygame.draw.rect(self.screen, GREEN, (health_x, health_y, current_health_width, health_height))
            
        # Draw shield bar if player has shield
        if self.cannon and self.cannon.has_shield and self.cannon.shield_hp > 0:
            shield_width = 200
            shield_height = 10
            shield_x = health_x
            shield_y = health_y + health_height + 5
            
            # Background (gray)
            pygame.draw.rect(self.screen, (100, 100, 100), (shield_x, shield_y, shield_width, shield_height))
            # Foreground (cyan)
            # Always use SHIELD_MAX_HP as base for visual calculation, even if actual max is higher
            current_shield_width = min(1.0, self.cannon.shield_hp / SHIELD_MAX_HP) * shield_width
            pygame.draw.rect(self.screen, (0, 255, 255), (shield_x, shield_y, current_shield_width, shield_height))
            
    def run(self):
        self.player_name = self.get_player_name()
        self.show_difficulty_menu()
        self.start_new_wave()
        
        while self.running:
            current_time = time.time()
            self.clock.tick(60)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and not self.between_waves:
                        lasers = self.cannon.shoot(current_time)
                        if lasers:
                            for laser in lasers:
                                self.lasers.add(laser)
                                self.all_sprites.add(laser)
                                pew_sound.play()
            
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                self.cannon.move('left')
            if keys[pygame.K_RIGHT]:
                self.cannon.move('right')
            
            self.update(current_time)
            
            self.screen.blit(background, (0, 0))  
            self.all_sprites.draw(self.screen)
            self.cannon.draw(self.screen)  
            self.cannon.draw_shield(self.screen)  
            
            self.draw_wave_info()
            self.draw_health_bar()
            
            if self.cannon.double_cannon_active or self.cannon.shotgun_active:
                status_font = pygame.font.Font(None, 24)
                y_offset = 80  
                
                if self.cannon.double_cannon_active:
                    time_left = int(self.cannon.double_cannon_end_time - current_time)
                    status_text = status_font.render(f'Double Cannon: {time_left}s', True, (0, 0, 255))
                    self.screen.blit(status_text, (10, y_offset))
                    y_offset += 25
                    
                if self.cannon.shotgun_active:
                    time_left = int(self.cannon.shotgun_end_time - current_time)
                    status_text = status_font.render(f'Space Shotgun: {time_left}s', True, ORANGE)
                    self.screen.blit(status_text, (10, y_offset))
            
            pygame.display.flip()
            
            if self.game_over:  
                self.save_score()
                return self.score
        
        return self.score

if __name__ == "__main__":
    player_name = None
    while True:
        game = Game()
        player_name = game.get_player_name()
        final_score = game.run()
        
        if not game.show_restart_menu(final_score):
            pygame.quit()
            exit()
