# Space Invaders

A modern take on the classic Space Invaders game, built with Python and Pygame. Fight waves of aliens, collect power-ups, and achieve the highest score!

## Features

### Core Gameplay
- Wave-based combat system
- Health and shield mechanics
- Score tracking system with local leaderboard
- Three difficulty levels affecting alien damage:
  - Easy: 8 damage
  - Medium: 15 damage
  - Hard: 25 damage

### Player Ship
- Health system (75 HP)
- Energy shield system (35 HP)
- Shield regeneration during wave breaks
- Smooth movement controls
- Various weapon systems through power-ups

### Power-Ups
1. **Giant Laser**
   - Larger, growing laser beam
   - Increased damage
   - Duration: 4 seconds

2. **Double Cannon**
   - Fires from two additional side cannons
   - Increased fire coverage
   - Duration: 12 seconds

3. **Space Shotgun**
   - Fires multiple spread shots
   - Great for crowd control
   - Duration: 8 seconds

4. **Energy Shield**
   - Provides 35 HP shield
   - Absorbs damage before health
   - Decays by 1 HP every 1.5 seconds

5. **Medkit**
   - Heals 5 HP per second
   - Duration: 5 seconds

### Enemies
- Animated alien sprites
- Random movement patterns
- Projectile attacks
- Increasing difficulty with each wave
- More aliens spawn in later waves

### Visual Effects
- Explosion animations
- Power-up visual indicators
- Health and shield bars
- Wave transition effects
- Custom sprites and textures

### Audio
- Laser sound effects
- Collision sounds
- Game over sound

## Controls
- **Left Arrow**: Move left
- **Right Arrow**: Move right
- **Space**: Fire weapon
- **ESC**: Pause/Menu

## Future Plans

### New Enemy Types
- Fast-moving scout aliens
- Armored heavy aliens
- Kamikaze aliens that rush the player
- Alien formations with unique attack patterns

### Boss Battles
- End-of-level boss encounters
- Unique boss mechanics and patterns
- Special rewards for defeating bosses
- Multi-phase boss fights

### Level System
- Distinct themed levels
- Progressive difficulty scaling
- Unique backgrounds per level
- Level-specific challenges

### New Power-Ups (Planned)
- Time slow
- Rapid fire mode
- Homing missiles
- Area denial weapons
- Shield regeneration boost

## Requirements
- Python 3.x
- Pygame
- Pillow (PIL)

## Installation
1. Clone the repository
2. Install required packages:
   ```bash
   pip install pygame pillow
   ```
3. Run the game:
   ```bash
   python space_invaders.py
   ```

## Credits
- Game assets and sounds from various free sources
- Built with Python and Pygame
- Original Space Invaders concept by Tomohiro Nishikado of which this game is inspired by
